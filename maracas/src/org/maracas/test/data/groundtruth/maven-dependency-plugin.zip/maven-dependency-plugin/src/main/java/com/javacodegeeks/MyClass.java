package com.javacodegeeks;

public class MyClass {

    public void myMethod() {
        // do some awesome stuffs
    }
}
